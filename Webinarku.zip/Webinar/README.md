# A22_Webinarku
Membuat tampilan HTML &amp; CSS
Pembagian Tugas:
- Header : Irham Naqibanussalam
- Main top: Irma Wati Sutrisna
- Main bottom: Irfan Nugraha
- Footer: Fajar Rizki Putra
- Responsif: Falya Charismatul Ayza
